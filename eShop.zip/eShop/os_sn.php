<?php

defined('_JEXEC') or die();

class os_sn extends os_payment
{

	public function __construct($params)
	{
        $config = array(
            'type' => 0,
            'show_card_type' => false,
            'show_card_holder_name' => false
        );
        parent::__construct($params, $config);
	}

	public function processPayment($data)
	{
		$siteUrl = JURI::base();
		$countryInfo = EshopHelper::getCountry($data['payment_country_id']);
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security
		$callBack = $siteUrl . 'index.php?option=com_eshop&task=checkout.verifyPayment&payment_method=os_sn&oID='.$data['order_id'].'&md='.$md.'&sec='.$sec;
		$transaction->custom = round(1,9999999);


								$data_string = json_encode(array(
						'pin'=> $this->params->get('sn_api'),
						'price'=> $data['total'],
						'callback'=> $callBack ,
						'order_id'=> $transaction->custom,
						'ip'=> $_SERVER['REMOTE_ADDR'],
						'callback_type'=>2
						));

						$ch = curl_init('https://developerapi.net/api/v1/request');
						curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, array(
						'Content-Type: application/json',
						'Content-Length: ' . strlen($data_string))
						);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
						$result = curl_exec($ch);
						curl_close($ch);


						$json = json_decode($result,true);
						if(!empty($json['result']) AND $json['result'] == 1)
						{
							
									// Set Session
						$_SESSION[$sec] = [
							'price'=>$data['total'] ,
							'order_id'=>$transaction->custom ,
							'au'=>$json['au'] ,
						];
			echo '<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>';

		}
		else
		{
			echo '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">خطای غیر منتظره ('.$json['msg'].') !!!</p>';
		}
		exit;
	}


	protected function validate()
	{


		@session_start();
// Security
@session_start();
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security
//get data from session
$transData = $_SESSION[$sec];
$au=$transData['au']; //
		$orderID = $transData['order_id']; //
		$amount  = $transData['price']; //
if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl ){
		
// CallBack
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $this->params->get('sn_api'),
'price' => $amount,
'order_id' => $orderID,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);

		
		$this->logGatewayData(' OrderID: ' . $orderID . ' au:'.$au . ' amount:'.$amount . ' res:'.$res . ' time:'.date('Y/m/d H:i:s') );
		if($json['result'] == 1)
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">پرداخت با موفقیت انجام شد.<br />شماره پیگیری : '.$au.'<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return true;
		}
		else
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">خطا در پرداخت.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return false;
		}
		}
		else
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">خطا در پرداخت.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return false;
		}
	}

	public function verifyPayment()
	{
		$row = JTable::getInstance('Eshop', 'Order');
		$id = $_REQUEST['oID']; 
		$row->load($id);
		if ($row->order_status_id == EshopHelper::getConfigValue('complete_status_id'))
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">پرداخت قبلا ثبت شده.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return false;
		}
		$ret = $this->validate();
		$currency = new EshopCurrency();
		if ($ret)
		{
			@session_start();
			//get data from session
$transData = $_SESSION[$sec];
$au=$transData['au']; //
		$orderID = $transData['order_id']; //
		$amount  = $transData['price']; //
			$row->transaction_id = $au; 
			$row->order_status_id = EshopHelper::getConfigValue('complete_status_id');
			$row->store();
			EshopHelper::completeOrder($row);
			
			if (EshopHelper::getConfigValue('order_alert_mail'))
			{
				EshopHelper::sendEmails($row);
			}
			return true;
		}
		else
		{
			return false;
		}
	}
}